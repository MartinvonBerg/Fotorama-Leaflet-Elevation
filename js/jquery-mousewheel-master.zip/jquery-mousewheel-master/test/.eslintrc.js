module.exports = {
    "globals": {
        "QUnit": "readonly"
    },
    "rules": {
    }
};